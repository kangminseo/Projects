package mvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.model.BoardDAO;
import mvc.model.BoardDTO;

public class BoardController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    static final int LISTCOUNT = 5; 

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String RequestURI = request.getRequestURI();
        String contextPath = request.getContextPath();
        String command = RequestURI.substring(contextPath.length());

        // 설정 이동
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html; charset=utf-8");

        try {
            if (command.equals("/BoardListAction.do")) { // 등록된 글 목록 페이지 출력하기
                requestBoardList(request);
                forward(request, response, "./board/list.jsp");
            } else if (command.equals("/BoardWriteForm.do")) { // 글 등록 페이지 출력하기
                requestLoginName(request);
                forward(request, response, "./board/writeForm.jsp");
            } else if (command.equals("/BoardWriteAction.do")) { // 새로운 글 등록하기
                requestBoardWrite(request);
                redirect(response, request.getContextPath() + "/BoardListAction.do");
            } else if (command.equals("/BoardViewAction.do")) { // 선택된 글 상세 페이지 가져오기
                requestBoardView(request);
                forward(request, response, "./board/view.jsp");
            } else if (command.equals("/BoardUpdateAction.do")) { // 선택된 글 내용 수정하기
                requestBoardUpdate(request, response);
                redirect(response, request.getContextPath() + "/BoardListAction.do");
            } else if (command.equals("/BoardDeleteAction.do")) { // 선택된 글 삭제하기
                requestBoardDelete(request, response);
                redirect(response, request.getContextPath() + "/BoardListAction.do");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 등록된 글 목록 가져오기    
    private void requestBoardList(HttpServletRequest request){
            
        BoardDAO dao = BoardDAO.getInstance();
        List<BoardDTO> boardlist = new ArrayList<BoardDTO>();
        
        int pageNum = 1;
        int limit = LISTCOUNT;
        
        if (request.getParameter("pageNum") != null)
            pageNum = Integer.parseInt(request.getParameter("pageNum"));

        String items = request.getParameter("items");
        String text = request.getParameter("text");

        int total_record = dao.getListCount(items, text);
        boardlist = dao.getBoardList(pageNum, limit, items, text);

        int total_page = (int) Math.ceil((double) total_record / limit);

        request.setAttribute("pageNum", pageNum);           
        request.setAttribute("total_page", total_page);   
        request.setAttribute("total_record", total_record);
        request.setAttribute("boardlist", boardlist);                             
    }

    // 인증된 사용자명 가져오기
    private void requestLoginName(HttpServletRequest request){
        String id = request.getParameter("id");
        BoardDAO dao = BoardDAO.getInstance();
        String name = dao.getLoginNameById(id);
        request.setAttribute("name", name);    
    }

    // 새로운 글 등록하기
    private void requestBoardWrite(HttpServletRequest request){
        BoardDAO dao = BoardDAO.getInstance();        
        BoardDTO board = new BoardDTO();
        board.setId(request.getParameter("id"));
        board.setName(request.getParameter("name"));
        board.setSubject(request.getParameter("subject"));
        board.setContent(request.getParameter("content"));

        java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy/MM/dd(HH:mm:ss)");
        String regist_day = formatter.format(new java.util.Date());

        board.setHit(0);
        board.setRegist_day(regist_day);
        board.setIp(request.getRemoteAddr());

        dao.insertBoard(board);                    
    }

    // 선택된 글 상세 페이지 가져오기
    private void requestBoardView(HttpServletRequest request){
        BoardDAO dao = BoardDAO.getInstance();
        int num = Integer.parseInt(request.getParameter("num"));
        int pageNum = Integer.parseInt(request.getParameter("pageNum"));    

        BoardDTO board = dao.getBoardByNum(num, pageNum);

        request.setAttribute("num", num);         
        request.setAttribute("page", pageNum);
        request.setAttribute("board", board);                    
    }

    // 선택된 글 내용 수정하기
    private void requestBoardUpdate(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int num = Integer.parseInt(request.getParameter("num"));
        int pageNum = Integer.parseInt(request.getParameter("pageNum"));

        BoardDAO dao = BoardDAO.getInstance();
        BoardDTO board = dao.getBoardByNum(num, pageNum);

        // 로그인된 사용자의 ID 가져오기
        String loginId = (String) request.getSession().getAttribute("UserId");

        // 글의 작성자 ID 가져오기
        String writerId = board.getId();

        // 관리자 ID
        String adminId = "admin"; // 예시로 admin ID 설정

        // 작성자와 로그인한 사용자가 관리자인지 체크
        if (loginId != null && (loginId.equals(writerId) || loginId.equals(adminId))) {
            board.setSubject(request.getParameter("subject"));
            board.setContent(request.getParameter("content"));
            board.setIp(request.getRemoteAddr());

            dao.updateBoard(board);
        } else {
            // 권한이 없는 경우 처리 (예: 에러 메시지 출력 또는 다른 페이지로 리다이렉트)
            response.sendRedirect("error.jsp");
        }
    }

    // 선택된 글 삭제하기
    private void requestBoardDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int num = Integer.parseInt(request.getParameter("num"));
        int pageNum = Integer.parseInt(request.getParameter("pageNum"));

        BoardDAO dao = BoardDAO.getInstance();
        BoardDTO board = dao.getBoardByNum(num, pageNum);

        // 로그인된 사용자의 ID 가져오기
        String loginId = (String) request.getSession().getAttribute("UserId");

        // 글의 작성자 ID 가져오기
        String writerId = board.getId();

        // 관리자 ID
        String adminId = "admin"; // 예시로 admin ID 설정

        // 작성자와 로그인한 사용자가 관리자인지 체크
        if (loginId != null && (loginId.equals(writerId) || loginId.equals(adminId))) {
            dao.deleteBoard(num);
        } else {
            // 권한이 없는 경우 처리 (예: 에러 메시지 출력 또는 다른 페이지로 리다이렉트)
            response.sendRedirect("error.jsp");
        }
    }

    private void forward(HttpServletRequest request, HttpServletResponse response, String path) throws ServletException, IOException {
        if (!response.isCommitted()) {
            RequestDispatcher dispatcher = request.getRequestDispatcher(path);
            dispatcher.forward(request, response);
        }
    }

    private void redirect(HttpServletResponse response, String url) throws IOException {
        if (!response.isCommitted()) {
            response.sendRedirect(url);
        }
    }
}
