package mvc.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mvc.model.ProductDAO;
import mvc.model.ProductDTO;

public class ProductController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String command = request.getServletPath();
        
        if (command.equals("/ProductListAction.pdo")) {
            requestProductList(request);
            RequestDispatcher rd = request.getRequestDispatcher("./product/list.jsp");
            rd.forward(request, response);
        } else if (command.equals("/ProductViewAction.pdo")) { 
            requestProductView(request);
            RequestDispatcher rd = request.getRequestDispatcher("./product/view.jsp");
            rd.forward(request, response);
        }
    }

    public void requestProductList(HttpServletRequest request) {
        // 상품 목록을 요청하는 코드
    }

    public void requestProductView(HttpServletRequest request) {
        String productId = request.getParameter("id"); // 요청에서 상품 ID를 가져옴
        
        ProductDAO productDAO = ProductDAO.getInstance();
        ProductDTO product = productDAO.getProductById(productId); // 데이터베이스에서 상품 정보 가져오기
        
        request.setAttribute("product", product); // 상품 정보를 요청 속성에 설정
    }
}
