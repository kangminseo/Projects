package mvc.model;

import java.sql.*;
import mvc.model.ProductDTO;
import mvc.database.DBConnection;

public class ProductDAO {
	
	private static ProductDAO instance;
	
	private ProductDAO() {
	}

	public static ProductDAO getInstance() {
		if (instance == null)
			instance = new ProductDAO();
		return instance;
	}
	
	public ProductDTO getProductById(String productId) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProductDTO product = new ProductDTO();
		
		String sql = "SELECT  * FROM product WHERE p_id=?";
		try{
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, productId);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				product.setId(rs.getString("p_id"));
				product.setName(rs.getString("p_name"));
				product.setUnitPrice(rs.getInt("p_unitPrice"));
				product.setDescription(rs.getString("p_description"));
				product.setCategory(rs.getString("p_category"));
				product.setManufacturer(rs.getString("p_manufacturer"));
				product.setUnitsInStock(rs.getInt("p_unitsInStock"));
				product.setCondition(rs.getString("p_condition"));
				product.setFilename(rs.getString("p_filename"));
			}
		}catch(Exception ex) {
			System.out.println("ProductById() 에러 : " + ex);
		}finally {
			try {				
				if (rs != null) 
					rs.close();							
				if (pstmt != null) 
					pstmt.close();				
				if (conn != null) 
					conn.close();
			} catch (Exception ex) {
				throw new RuntimeException(ex.getMessage());
			}
		}
		return product;
	}	
	
}